import { GoogleGenAI, Type } from '@google/genai';
import { Language, ClassAnalysis } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const analysisSchema = {
    type: Type.OBJECT,
    properties: {
        classSummary: {
            type: Type.STRING,
            description: "A brief, 2-4 sentence summary of the entire class's performance, highlighting common challenges or overall progress. This is for the teacher's eyes only."
        },
        strugglingStudents: {
            type: Type.ARRAY,
            description: "An array of reports ONLY for students who are consistently scoring low (e.g., below 6 out of 10) or showing a downward trend. Do NOT include high-performing students.",
            items: {
                type: Type.OBJECT,
                properties: {
                    studentName: { type: Type.STRING },
                    parentReport: { 
                        type: Type.STRING, 
                        description: "A polite, encouraging, and constructive report written for the student's parents. It should start with a positive note, gently state the weak areas, and suggest collaboration. It MUST NOT use jargon. Keep it under 100 words."
                    },
                    weakAreas: {
                        type: Type.ARRAY,
                        description: "A list of specific topics where the student struggled.",
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                topic: { type: Type.STRING },
                                suggestion: { type: Type.STRING, description: "A one-sentence actionable suggestion for this topic." }
                            },
                            required: ['topic', 'suggestion']
                        }
                    }
                },
                required: ['studentName', 'parentReport', 'weakAreas'],
            }
        }
    },
    required: ['classSummary', 'strugglingStudents']
};


export async function analyzeStudentData(subject: string, csvData: string, language: Language): Promise<ClassAnalysis> {
    const langInstruction = language === 'ur' ? 'Urdu' : 'English';
    const prompt = `
        You are 'TaleemRadar', an expert AI teaching assistant in Pakistan. Your task is to analyze student test data and generate reports for parents. Your tone should be professional, empathetic, and constructive.

        Context: A teacher has provided 4 weeks of test score data (out of 10) for the subject "${subject.replace(/_/g, ' ')}". The data is from a spreadsheet and is in CSV format.

        Data:
        \`\`\`csv
        ${csvData}
        \`\`\`

        Task:
        1.  Carefully analyze the provided data for all students.
        2.  Identify students who are "struggling". A struggling student is one who consistently scores low (e.g., average score below 6) or shows a significant decline in performance.
        3.  For EACH struggling student you identify, create a personalized report for their parents. This report must be encouraging and focus on collaboration, not blame.
        4.  Provide a brief overall summary for the teacher.
        5.  The entire response (summaries, reports, topics, suggestions) MUST be in the ${langInstruction} language.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: 'application/json',
                responseSchema: analysisSchema,
            },
        });
        
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as ClassAnalysis;

    } catch (error) {
        console.error('Error fetching analysis from Gemini API:', error);
        throw new Error('Failed to analyze student data.');
    }
}