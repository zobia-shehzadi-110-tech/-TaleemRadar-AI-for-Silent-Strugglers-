import React, { useState } from 'react';
import { ClassAnalysis, Language, StrugglingStudentReport } from '../types';
import { LOCALIZED_STRINGS } from '../constants';
import { CopyIcon } from './icons';

interface AnalysisReportDisplayProps {
  result: ClassAnalysis;
  onReset: () => void;
  language: Language;
}

const StudentReportCard: React.FC<{ report: StrugglingStudentReport, language: Language }> = ({ report, language }) => {
    const [copied, setCopied] = useState(false);
    const currentStrings = LOCALIZED_STRINGS[language];

    const handleCopy = () => {
        navigator.clipboard.writeText(report.parentReport);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="bg-white p-6 rounded-lg shadow-md border border-slate-200">
            <div className="flex justify-between items-center mb-4">
                <h4 className="text-xl font-bold text-slate-800">{report.studentName}</h4>
                <button
                    onClick={handleCopy}
                    className={`px-3 py-1.5 text-sm font-semibold rounded-md flex items-center space-x-2 rtl:space-x-reverse transition-colors ${copied ? 'bg-green-500 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'}`}
                >
                    <CopyIcon className="h-4 w-4" />
                    <span>{copied ? currentStrings.reportCopiedButton : currentStrings.copyReportButton}</span>
                </button>
            </div>
            <p className="text-slate-600 leading-relaxed whitespace-pre-wrap mb-6">{report.parentReport}</p>
            
            <h5 className="font-semibold text-slate-700 mb-3">{currentStrings.weakAreasTitle}</h5>
            <div className="space-y-2">
                {report.weakAreas.map((area, index) => (
                    <div key={index} className="p-3 bg-slate-50 rounded-md">
                        <p className="font-semibold text-slate-800">{area.topic}</p>
                        <p className="text-sm text-slate-600">{area.suggestion}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};


const AnalysisReportDisplay: React.FC<AnalysisReportDisplayProps> = ({ result, onReset, language }) => {
  const currentStrings = LOCALIZED_STRINGS[language];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-10">
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-teal-500 to-cyan-500 text-transparent bg-clip-text mb-2">
                {currentStrings.analysisTitle}
            </h1>
        </div>
      
      <div className="mb-12">
        <h2 className="text-2xl md:text-3xl font-bold text-slate-800 text-center mb-4">
          {currentStrings.classSummaryTitle}
        </h2>
        <div className="bg-white p-6 rounded-lg shadow-md border border-slate-200">
          <p className="text-slate-600 leading-relaxed whitespace-pre-wrap">{result.classSummary}</p>
        </div>
      </div>
    
      <div>
        <h2 className="text-2xl md:text-3xl font-bold text-slate-800 text-center mb-4">
          {currentStrings.strugglingStudentsTitle}
        </h2>
        
        {result.strugglingStudents.length > 0 ? (
            <div className="space-y-8">
                {result.strugglingStudents.map((report, index) => (
                    <StudentReportCard key={index} report={report} language={language} />
                ))}
            </div>
        ) : (
            <div className="text-center p-8 bg-white rounded-lg shadow-md border border-slate-200">
                <p className="text-slate-600">No struggling students were identified based on the provided data. Great job, class!</p>
            </div>
        )}


        <div className="text-center mt-12">
            <button
                onClick={onReset}
                className="px-8 py-3 bg-slate-700 text-white font-semibold rounded-lg shadow-md hover:bg-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-opacity-50 transition-transform transform hover:scale-105"
            >
                {currentStrings.startOverButton}
            </button>
        </div>
      </div>
    </div>
  );
};

export default AnalysisReportDisplay;
