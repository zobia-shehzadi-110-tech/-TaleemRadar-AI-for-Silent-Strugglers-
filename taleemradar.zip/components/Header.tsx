import React from 'react';
import { Language } from '../types';
import { LOCALIZED_STRINGS } from '../constants';

interface HeaderProps {
  language: Language;
  setLanguage: (lang: Language) => void;
}

const Header: React.FC<HeaderProps> = ({ language, setLanguage }) => {
  const currentStrings = LOCALIZED_STRINGS[language];
  const otherLanguage: Language = language === 'en' ? 'ur' : 'en';

  const toggleLanguage = () => {
    setLanguage(otherLanguage);
  };

  return (
    <header className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="text-center">
          <h1 className="text-xl md:text-2xl font-bold bg-gradient-to-r from-teal-500 to-cyan-500 text-transparent bg-clip-text">
            {currentStrings.appName}
          </h1>
          <p className="text-xs text-slate-500 hidden sm:block">{currentStrings.tagline}</p>
        </div>
        <button
          onClick={toggleLanguage}
          className="px-4 py-2 text-sm font-semibold text-slate-700 bg-slate-100 border border-slate-200 rounded-lg hover:bg-slate-200 transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-500"
        >
          {LOCALIZED_STRINGS[otherLanguage].appName.split(' ')[0]}
        </button>
      </div>
    </header>
  );
};

export default Header;
