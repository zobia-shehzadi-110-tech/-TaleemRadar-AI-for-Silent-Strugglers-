import React, { useState } from 'react';
import { Language, Subject } from '../types';
import { LOCALIZED_STRINGS, SUBJECTS_EN, SUBJECTS_UR } from '../constants';

interface DataInputFormProps {
  onSubmit: (subject: string, csvData: string) => void;
  language: Language;
}

const DataInputForm: React.FC<DataInputFormProps> = ({ onSubmit, language }) => {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [csvData, setCsvData] = useState<string>('');

  const currentStrings = LOCALIZED_STRINGS[language];
  const subjects = language === 'en' ? SUBJECTS_EN : SUBJECTS_UR;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(selectedSubject && csvData){
        onSubmit(selectedSubject.name, csvData);
    }
  }

  return (
    <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-lg border border-slate-200">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-800">{currentStrings.formTitle}</h2>
        <p className="text-slate-500 mt-2">{currentStrings.formSubtitle}</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
            <label htmlFor="subject" className="block text-sm font-medium text-slate-700 mb-2">{currentStrings.subjectLabel}</label>
            <select
                id="subject"
                name="subject"
                onChange={(e) => setSelectedSubject(subjects.find(s => s.id === e.target.value) || null)}
                className="block w-full p-3 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500"
                required
                defaultValue=""
            >
                <option value="" disabled>-- Select a subject --</option>
                {subjects.map(subject => (
                    <option key={subject.id} value={subject.id}>{subject.name}</option>
                ))}
            </select>
        </div>
        <div>
            <label htmlFor="csvData" className="block text-sm font-medium text-slate-700 mb-2">{currentStrings.dataInputLabel}</label>
            <textarea
                id="csvData"
                name="csvData"
                rows={10}
                value={csvData}
                onChange={(e) => setCsvData(e.target.value)}
                className="block w-full p-3 bg-slate-50 border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 font-mono text-sm"
                placeholder={currentStrings.dataInputPlaceholder}
                required
            />
        </div>
        <button
          type="submit"
          disabled={!selectedSubject || !csvData}
          className="w-full py-3 px-6 text-lg font-semibold text-white bg-gradient-to-r from-teal-500 to-cyan-500 rounded-lg shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed disabled:shadow-lg transition-all transform hover:scale-105"
        >
          {currentStrings.analyzeButton}
        </button>
      </form>
    </div>
  );
};

export default DataInputForm;
